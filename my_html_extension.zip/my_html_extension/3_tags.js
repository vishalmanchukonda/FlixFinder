document.addEventListener('DOMContentLoaded', function() {
    document.getElementById('btn4').addEventListener('click', function() {
        window.location.href = "4_movie.html";
    });
});
document.addEventListener('DOMContentLoaded', function() {
    document.getElementById('btn4').addEventListener('click', function() {
        chrome.tabs.query({ active: true, currentWindow: true }, function(tabs) {
            chrome.tabs.update(tabs[0].id, { url: "https://www.netflix.com/title/60028202" });
        });
    });
});
document.addEventListener('DOMContentLoaded', function() {
    const buttons = document.querySelectorAll('.block');
    buttons.forEach(function(button) {
        button.addEventListener('click', function() {
            button.style.backgroundColor = '#DB202C'; 
        });
    });
});