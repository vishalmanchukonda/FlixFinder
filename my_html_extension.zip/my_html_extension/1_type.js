document.addEventListener('DOMContentLoaded', function() {
    document.getElementById('btn1').addEventListener('click', function() {
        window.location.href = "2_genre.html";
    });
    document.getElementById('btn2').addEventListener('click', function() {
        window.location.href = "2_genre.html";
    });
});