document.addEventListener('DOMContentLoaded', function() {
    document.getElementById('btn3').addEventListener('click', function() {
        window.location.href = "3_tags.html";
    });
});